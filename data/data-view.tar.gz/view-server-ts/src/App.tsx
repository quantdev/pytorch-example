// import React from 'react';
// import logo from './logo.svg';
// import './App.css';
// import Grid from "./Grid";
//
// function App() {
//   return (<Grid/>);
// }
//
// export default App;

import * as React from "react";
import {Client, DefaultServerChooser, DefaultSubscriptionManager} from "amps";
import Grid from "./Grid";
import './App.css';
import 'ag-grid-community/dist/styles/ag-theme-balham-dark.css';
import { curCol } from "./helpers";

// constants
const HOST = 'linux';
const PORT = '9008';

type AppState = {
    client: Client | null;
};

class App extends React.Component<{}, AppState>{
    constructor(props: any) {
        super(props);
        this.state = {client: null};
    }

    render() {
        // client is not ready yet, render "Loading..." label only
        if (!this.state.client) {
            return (<div>Loading....</div>);
        }

        return (
            <div className="ag-theme-balham-dark" style={{display: 'flex', justifyContent: 'center', flexWrap: 'wrap'}}>
                {/*<Grid*/}
                {/*    client={this.state.client}*/}
                {/*    columnDefs={[*/}
                {/*        {headerName: 'Symbol', field: 'symbol'},*/}
                {/*        {headerName: 'Bid', field: 'bid', sort: 'desc'},*/}
                {/*        {headerName: 'Ask', field: 'ask'}*/}
                {/*    ]}*/}
                {/*    topic="market_data"*/}
                {/*    options="oof,conflation=3000ms,top_n=20,skip_n=0"*/}
                {/*    orderBy="/bid DESC"*/}
                {/*/>*/}

                <Grid
                    client={this.state.client}
                    title="Top 20 Symbols by Bid"
                    columnDefs={[
                        {headerName: 'Symbol', field: 'symbol'},
                        curCol({headerName: 'Bid', field: 'bid'}),
                        curCol({headerName: 'Ask', field: 'ask', sort: 'asc'})
                    ]}
                    topic="market_data"
                    options="oof,conflation=500ms,top_n=20,skip_n=10"
                    orderBy="/ask ASC"
                    filter="LENGTH(/symbol) = 3"
                    // showFilterBar
                />

                <Grid
                    client={this.state.client}
                    title="Top 50 Symbols by Bid"
                    columnDefs={[
                        {headerName: 'Symbol', field: 'symbol'},
                        curCol({headerName: 'Bid', field: 'bid'}),
                        curCol({headerName: 'Ask', field: 'ask', sort: 'asc'})
                    ]}
                    topic="market_data"
                    options="oof,conflation=500ms,top_n=50,skip_n=10"
                    orderBy="/ask ASC"
                    // filter="LENGTH(/symbol) = 3"
                    // showFilterBar
                />

            </div>
        );

    }

    // create a client once the component did mount
    async componentDidMount() {
        // create the server chooser
        const chooser = new DefaultServerChooser();
        chooser.add(`ws://${HOST}:${PORT}/amps/json`);

        // create the AMPS HA client object
        const client = new Client('view-server');
        client.serverChooser(chooser);
        client.subscriptionManager(new DefaultSubscriptionManager());

        // now we can establish connection
        await client.connect();

        // update the state
        this.setState({ client });
    }

    // disconnect the client from AMPS when the component is destructed
    componentWillUnmount() {
        if (this.state.client) {
            this.state.client.disconnect();
        }
    }
}

export default App;

