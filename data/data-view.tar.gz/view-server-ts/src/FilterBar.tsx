import * as React from 'react';


type FilterBarProps = {
    value: string;
    onValueChange(value: string): void;
};


const FilterBar = ({ value, onValueChange }: FilterBarProps) => {
    const [inputValue, setInputValue] = React.useState(value || '');

    return (
        <div className="filter-bar">
            <form>
                <label>
                    <input
                        type="text"
                        value={inputValue}
                        onChange={(event: React.ChangeEvent<HTMLInputElement>) => setInputValue(event.target.value)}
                    />
                </label>
                <input type="button" value="Filter" onClick={() => onValueChange(inputValue)} />
            </form>
        </div>
    );
};


export default FilterBar;