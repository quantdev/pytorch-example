import * as React from 'react'

import { AgGridReact } from "ag-grid-react";
import {ColDef, GridReadyEvent, GridSizeChangedEvent} from "ag-grid-community";
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import {Client, Command, Message} from "amps";
import FilterBar from "./FilterBar";

type DataRow = {
    key: string;
};

type GridProps= {
    client: Client;

    title?: string;

    width?: number | string;
    height?: number | string;

    columnDefs: ColDef[]

    topic: string;
    orderBy: string;
    options: string;

    filter?: string;
    showFilterBar?: boolean;
}

type GridState = {
    rowData: DataRow[];
};


const columnDefs: ColDef[] = [
    {headerName: 'Symbol', field: 'symbol'},
    {headerName: 'Bid', field: 'bid', sort: 'desc'},
    {headerName: 'Ask', field: 'ask'}
];

const matcher = (message: Message) => (row: DataRow) => row.key === message.header.sowKey();

export default class Grid extends React.Component<GridProps, GridState> {
    constructor(props: GridProps) {
        super(props)
        this.state = {rowData: []};
    }

    private subId?: string;
    private filter?: string;

    async sowAndSubscribe(filter: string | undefined = (this.filter || this.props.filter)) {
        this.filter = filter;

        // // if we had a running subscription already, we need to unsubscribe from it
        // if (this.subId) {
        //     this.props.client.unsubscribe(this.subId);
        //     this.setState({rowData: [], error: null});
        //     this.subId = undefined;
        // }

        // create a command object
        const cmd = new Command('sow_and_subscribe');
        cmd.topic(this.props.topic );
        cmd.orderBy(this.props.orderBy);
        cmd.options(this.props.options);

        if (this.props.filter) {
            cmd.filter(this.props.filter);
        }

        // execute the command
        let rows: DataRow[];
        this.subId = await this.props.client.execute(cmd, (message: Message) => {
            switch (message.header.command()) {
                case 'group_begin': // Begin receiving the initial dataset
                    rows = [];
                    break;
                case 'sow': // This message is a part of the initial dataset
                    message.data.key = message.header.sowKey();
                    rows.push(message.data);
                    break;
                case 'group_end': // Initial Dataset has been delivered
                    this.setState({ rowData: rows });
                    break;
                case 'oof': // Out-of-Focus -- a message should no longer be in the grid
                    this.onOOF(message);
                    break;
                default: // Publish -- either a new message or an update
                    this.onPublish(message);
            }
        });
    }

    onOOF(message: Message) {
        const rowIndex = this.state.rowData.findIndex(matcher(message));

        if (rowIndex >= 0) {
            const rows = this.state.rowData.filter(row => row.key !== message.header.sowKey());
            this.setState({ rowData: rows });
        }
    }

    onPublish(message: Message) {
        const rowIndex = this.state.rowData.findIndex(matcher(message));
        const rows = this.state.rowData.slice();

        if (rowIndex >= 0) {
            rows[rowIndex] = {...rows[rowIndex], ...message.data};
        }
        else {
            message.data.key = message.header.sowKey();
            rows.push(message.data);
        }

        this.setState({ rowData: rows });
    }

    render() {
        return (
            <div className="ag-theme-balham" style={{
                height: this.props.height || '595px',
                width: this.props.width || '600px'
            }}>
                <div className="grid-header">{this.props.title}</div>
                {this.props.showFilterBar &&
                <FilterBar
                    value={this.props.filter || ''}
                    onValueChange={async value => await this.sowAndSubscribe(value)}
                />
                }

                <AgGridReact
                    animateRows

                    columnDefs={this.props.columnDefs}

                    // we now use state to track row data changes
                    rowData={this.state.rowData}

                    // unique identification the row based on the SowKey
                    getRowNodeId={(row: DataRow) => row.key}

                    // the provided callback is invoked once the grid is initialized
                    onGridReady={(params: GridReadyEvent) => this.onGridReady(params)}

                    // react update mechanism for efficient state merges
                    deltaRowDataMode

                    // resize columns on grid resize
                    onGridSizeChanged={(params: GridSizeChangedEvent) => params.api.sizeColumnsToFit()}
                />
            </div>
        );
    }

    async onGridReady(params: GridReadyEvent) {
        // resize columns to fit the width of the grid
        params.api.sizeColumnsToFit();

        try {
            // subscribe to the topic data and atomic updates
            await this.sowAndSubscribe();
        }
        catch (err) {
            this.setState({rowData: []});
            console.error('err: ', err);
        }
    }
}